"""utility functions here"""
def helper():
    """helper function"""
    print("helper: Here you can store all your utility functions")
