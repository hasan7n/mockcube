import torch

if not torch.cuda.is_available():
    print("\n!!!WARNING!!! Could not detect GPU. Please check why the cube cannot access GPUs.\n")
else:
    print("gpu detected!")